﻿


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace LopezLem_EvaluacionFinal //corregir // Se recomienda utilizar un nombre de espacio más representativo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Configurar las columnas del DataGridView
            dataGridView1.Columns.Add("valor", "Categoria");
            dataGridView1.Columns.Add("categoria", "valor");
            

            // Configurar la gráfica de barras
            chart1.Series.Clear();

            // Agregar algunas filas de ejemplo
            dataGridView1.Rows.Add("Categoria 1", 10);
            dataGridView1.Rows.Add("Categoria 2", 28);
            dataGridView1.Rows.Add("Categoria 3", 22);
            dataGridView1.Rows.Add("Categoria 4", 35);
            dataGridView1.Rows.Add("Categoria 5", 38);

            // Generar la gráfica de barras a partir de los datos del DataGridView
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                string categoria = row.Cells[0].Value?.ToString(); // Utilizar el operador ? para manejar nulos
                if (categoria != null)
                {
                    chart1.Series.Add(categoria);

                    for (int i = 1; i < dataGridView1.Columns.Count; i++)
                    {
                        string trimestre = dataGridView1.Columns[i].HeaderText;
                        int valor = Convert.ToInt32(row.Cells[i].Value ?? 0); // Asignar 0 en caso de valor nulo
                        chart1.Series[categoria].Points.AddXY(trimestre, valor);
                    }
                }
            }

            // Personalizar la apariencia de la gráfica
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.ChartAreas[0].AxisX.Title = "categoria";
            chart1.ChartAreas[0].AxisY.Title = "Valor";
            chart1.Titles.Add("Análisis y Visualización de datos");
        }
    }
}







